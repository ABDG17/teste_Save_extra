## Fazer branches caso faça uma mudança. 
O script para a branche esta na na comunidade "CyberSafeZone". 
* [link para o script](https://github.com/CyberSafeZone/Script)
