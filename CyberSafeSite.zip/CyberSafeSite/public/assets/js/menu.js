
document.querySelector('#menu-mobile').addEventListener('click', () => {
    document.querySelector('.mobile-navbar').classList.toggle('active')
});


